exports.homePage=class homePage{
    constructor(page){
        this.page=page;
        this.productList="//*[@id='tbodyid']";
        this.addToCartButton="/html/body/div[5]/div/div[2]/div[2]/div/a";
        this.cart="//a[@id='cartur']"
    }
    async addProductToCart(productName){
// time for loading product list

await this.page.waitForSelector(this.productList)
// const productList=await this.page.$$(this.productList)
// for(const product of productList){
//     if(productName==await product.textContent()){
//         await product.click();
//         break;
//     }
// }

await this.page.locator(this.productList).first().waitFor();
await this.page.locator(this.productList).filter({hasText:productName}).first().click()
this.page.on('dialog',async dialog=>{
    if(dialog.message().includes('added')){
        await dialog.accept()
    }
})
await this.page.locator(this.addToCartButton).click();

    }

    async goToCart(){
        await this.page.locator(this.cart).click()
    }
}