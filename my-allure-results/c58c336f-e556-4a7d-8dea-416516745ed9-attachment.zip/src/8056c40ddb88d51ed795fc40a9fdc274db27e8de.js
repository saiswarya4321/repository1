exports.homePage=class homePage{
    constructor(page){
        this.page=page;
        this.productList="//*[@id='tbodyid']";
        this.addToCartButton="//*[@id='tbodyid']/div[2]/div/a";
        this.cart="//a[@id='cartur']"
    }
    async addProductToCart(productName){
// time for loading product list

await this.page.waitForSelector(this.productList)
const productList=await this.page.$$(this.productList)
for(const product of productList){
    if(productName==await product.textContent()){
        await product.click();
        break;
    }
}
this.page.on('dialog',async dialog=>{
    if(dialog.message().includes('added')){
        await dialog.accept()
    }
})
await this.page.locator(this.addToCartButton).click();

    }

    async goToCart(){
        await this.page.locator(this.cart).click()
    }
}