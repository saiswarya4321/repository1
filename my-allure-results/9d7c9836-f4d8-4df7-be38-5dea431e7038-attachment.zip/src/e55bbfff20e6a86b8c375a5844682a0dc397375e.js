const{test,expect}=require('@playwright/test')
const Login=require('./login.spec.js')

test('pom test two',async({page})=>{
    const username="standard_user";
    const password="secret_sauce";

    //login 
    const loginobj=new Login(page)
   await loginobj.clickToLogin();
    await loginobj.validLogin(username,password)
})