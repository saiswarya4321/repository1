const{expect}=require("@playwright/test")

class Summary{
    constructor(page){
this.page=page;
this.subTotal=page.locator(".summary_total_label")
this.finishBtn=page.getByRole('button',{name:'finish'})
    }

    async summaryDetails(){
        const itemTotal= this.subTotal.textContent()
        console.log("SubTotal",itemTotal);
await expect(this.itemTotal).toContain('Item total: $')
        
    }
    async finish(){
        await this.finish.click()
    }

}
module.exports=Summary