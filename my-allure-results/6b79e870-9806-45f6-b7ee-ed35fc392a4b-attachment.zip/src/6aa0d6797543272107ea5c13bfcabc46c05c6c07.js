const{test,expect}=require("@playwright/test")
const Data=require("../TestData/TestData.js")

test('External data reading',async({page})=>{
    await page.goto('https://www.saucedemo.com/')
//invalid username,valid password
await page.locator("#user-name").fill(Data.testData.login.invalidUsername);
await page.locator("#password").fill(Data.testData.login.validPassword)
await page.getByRole('button',{name:'login-button'}).click()
//await expect(page.locator('data-test="error"')).toContainText('Epic sadface')
const error= page.locator("[data-test='error']");
console.log("error",error)
await expect(error).toContainText('Epic sadface')

})