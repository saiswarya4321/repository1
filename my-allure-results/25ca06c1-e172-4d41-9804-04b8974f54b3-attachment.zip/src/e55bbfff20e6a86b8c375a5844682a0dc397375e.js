const{test,expect}=require('@playwright/test')
const login=require('./login.spec.js')

test('pom test two',async({page})=>{
    const username="standard_user";
    const password="secret_sauce";

    //login 
    const loginobj=new login(page)
    loginobj.clickToLogin();
    loginobj.validLogin(username,password)
})