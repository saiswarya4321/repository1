import { test, expect } from '@playwright/test';
import { loginPage } from './loginPage';




//login page

test('test',async({page})=>{
const login=new loginPage(page)
await login.gotoLoginPage()
await login.Login('sibivarughese','test@123')
})
